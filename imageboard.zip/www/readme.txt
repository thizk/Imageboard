|== Installation ==|

- Upload all content to your webhosting folder
- Edit the file core/init.php with your mysql database information
- Administrator Panel
	- URL: yourwebsite.com/panel
	- Username: admin
	- Password: administrator (change it)

- Requirements
	- FFMPEG : www.ffmpeg.org 
- Content
	- PAGE SETTINGS
	- POSTS
	- COMMENTS
	- CATEGORIES
	- ADVERTS
	- USERS (only admins)
	- REPORTS
	- ExPANDABLE IMAGES & VIDEOS
	- MULTILANGUAGE

- enjoy it!

|== Instalacion ==|

- Suba todo el contenido a su webhosting
- Edite el archivo core/init.php con la informacion de su base de datos mysql
- Panel Administrativo
	- URL: yourwebsite.com/panel
	- Usuario: admin
	- Contrase�a: administrator (cambiala)

- CONTENIDO
	- CONFIGURACION DE DATOS DE LA PAGINA
	- POSTS
	- COMENTARIOS
	- CATEGORIAS
	- PUBLICIDADES
	- USUARIOS (only admins)
	- REPORTES
	- IMAGENES & VIDEOS EXPANDIBLES
	- MULTILENGUAGE

- Requerimientos
	- FFMPEG: www.ffmpeg.org 

- Disfrutalo!

|--- ADVERTISING USE ---|
	Use:
		$advertising->random($type) // replace $type with the position you whant (example center)
	(if you want a new position , you need to create a new css class and put in the file you want)
