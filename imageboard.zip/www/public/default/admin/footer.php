   	<div class="wrapper">
            <div class="footer">
                       <?php page::render($copyright); ?>
            </div>
            <div class="clearFix"></div>
    </div>
  
</body>
</html>