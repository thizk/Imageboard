<?php include 'core/init.php'; ?>
<?php

// GET ACTION
$do = input::get('_r'); 

// START THE PAGE
$page->startUp('index');

?>